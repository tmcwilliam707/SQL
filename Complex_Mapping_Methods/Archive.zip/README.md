Complex Mapping methods for parsing JSON data in maps application 
